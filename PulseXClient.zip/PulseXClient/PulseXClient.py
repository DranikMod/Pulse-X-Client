from telethon import TelegramClient, events
import os
import importlib.util
from config import api_id, api_hash, session_name

client = TelegramClient(session_name, api_id, api_hash)

plugins = []

async def load_plugins():
    global plugins
    plugins = [] 
    plugin_folder = './plugins/'
    
    for filename in os.listdir(plugin_folder):
        if filename.endswith('.py'):
            path = os.path.join(plugin_folder, filename)
            spec = importlib.util.spec_from_file_location("plugin", path)
            plugin = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(plugin)
            plugins.append(plugin.Plugin(client))

async def send_message(event, message):
    await event.reply(message)

@client.on(events.NewMessage(pattern=r'\.pol'))
async def ping(event):

    if event.sender_id == client.get_me().id:
        await send_message(event, 'Pong!')

@client.on(events.NewMessage(pattern=r'\.reload'))
async def reload_plugins(event):
  
    if event.sender_id == client.get_me().id:
        await load_plugins()
        await send_message(event, 'Плагины перезагружены!')

async def main():
    await load_plugins()
    print("PulseXClient запущен!")
    await client.run_until_disconnected()

with client:
    client.loop.run_until_complete(main())

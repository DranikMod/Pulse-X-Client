# config.py

api_id = "твой_api_id"
api_hash = "твой_api_hash"
session_name = "PulseXClientSession"

# plugins/example_plugin.py

from telethon import events  

class Plugin:
    def __init__(self, client):
        self.client = client
        self.start()

    def start(self):
        @self.client.on(events.NewMessage(pattern=r'\.test'))
        async def test(event):
            await event.reply('Плагин работает! Пример плагина.')

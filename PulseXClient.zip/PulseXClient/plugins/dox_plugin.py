# plugins/dox_plugin.py

import random
from telethon import events
from asyncio import sleep

class Plugin:
    def __init__(self, client):
        self.client = client
        self.start()

    def start(self):
        @self.client.on(events.NewMessage(pattern=r'\.dox'))
        async def dox(event):
        
            dox_msg = [
                "⛓ <b>Нᴀчиnᴀю ᴅ0ᴋs...</b>", 
                "☠️ <b>3aпр0s принят, п0лучаю инф0рмацию...</b>", 
                "🚫 <b>п0шᴇл нахуй</b>"
            ]
            doox = random.choice(dox_msg)
            await event.reply(doox)
            await sleep(2)
            
            zapros_msg = [
                "💣 <b>П0лʏчᴀю 3ᴀпр0s</b> <code>[ 3% ] </code>",
                "💥 <b>Инф0рмᴀция не нᴀйдена</b>"
            ]
            zapros = random.choice(zapros_msg)    
            await event.reply(zapros)
            await sleep(1)

            progress_messages = [
                "🔄 <b>Sвᴇᴘяю s иnф0рмᴀциᴇй и3 бᴀ3 дᴀннblx</b> <code> [ 7% ]</code>",
                "❌ <b>Дᴀннblᴇ ʜᴇ s0ʙпᴀли, п0вт0ряᴇᴍ 3ᴀпр0с..</b> <code> [ 13% ]</code>",
                "♻️ <b>0брᴀбᴀтblвᴀю инф0рмᴀцию...</b> <code> [ 17% ]</code>",
                "♻️ <b>0брᴀбᴀтblвᴀю инф0рмᴀцию...</b> <code> [ 24% ]</code>",
                "🌀 <b>Ysкоряю процᴇss</b> <code> [ 37% ]</code>",
                "🌀 <b>Ysкоряю процᴇss</b> <code> [ 53% ]</code>",
                "🌀 <b>Ysкоряю процᴇss</b> <code> [ 78% ]</code>",
                "✅ <b>Инф0рмᴀция нᴀйдᴇʜᴀ</b> <code> [ 94% ]</code>",
                "🔁 <b>вblв0жу...</b> <code> [ 100% ]</code>"
            ]

            for msg in progress_messages:
                await event.reply(msg)
                await sleep(1)

            # Генерация случайной информации
            possible_numbers = [
                10000000000, 99999999999, 666666666, 282823483, 8889238883466, 
                3838339333, 833828483, 819283748, 3829444678, 79236932583, 
                79230352252, 79236785664
            ]
            random_number = random.choice(possible_numbers)

            countries = [
                "Россия", "США", "Китай", "Индия", "Бразилия", 
                "Австралия", "Франция", "Германия", "Канада"
            ]
            regions = [
                "Московская область", "Калифорния", "Техас", 
                "Нью-Йорк", "Париж", "Берлин", "Лондон"
            ]
            operators = [
                "Мегафон", "Билайн", "Теле2", "AT&T", "Verizon"
            ]
            names = [
                "Петр", "Анна", "Иван", "Мария", "Дмитрий", 
                "Ольга", "Сергей", "Екатерина"
            ]
            addresses = [
                "Санкт-Петербург, Невский проспект, 1", 
                "Москва, Красная площадь, 2", 
                "Лондон, Биг Бен", "Нью-Йорк, Таймс-сквер"
            ]
            birth_dates = [
                "14.01.2000", "16.06.1995", "14.08.1988", 
                "01.01.2001", "05.05.1990"
            ]
            viewers_counts = [0, 100, 500, 1000, 5000]

            result_message = (
                f"📱\n<b>├ Номер:</b> <code>{random_number}</code>\n"
                f"<b>├ Страна:</b> <code>{random.choice(countries)}</code>\n"
                f"<b>├ Регион:</b> <code>{random.choice(regions)}</code>\n"
                f"<b>└ Оператор:</b> <i>{random.choice(operators)}</i>\n\n"
                f"🏠 <b>Возможные адреса:</b> \n<i>{random.choice(addresses)}</i>\n\n"
                f"🏥 <b>Дата рождения:</b> <code>{random.choice(birth_dates)}</code>\n\n"
                f"👁 <b>Интересовались:</b> <code>{random.choice(viewers_counts)}</code> человек"
            )

            await sleep(2)
            await event.reply(result_message)
            
import typing
import json
import requests
from telethon import events

class Plugin:
    def __init__(self, client):
        self.client = client
        self.start()

    def deep_infra_chat(self, messages: typing.List[typing.Dict[str, str]]) -> typing.Union[str, None]:
        url: str = "https://api.deepinfra.com/v1/openai/chat/completions"
        headers: typing.Dict[str, str] = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
            'Content-Type': 'application/json',
        }

        data: typing.Dict[str, typing.Any] = json.dumps(
            {
                'model': 'meta-llama/Llama-2-70b-chat-hf',
                'messages': messages,
                'stream': False
            }, separators=(',', ':')
        )
        
        try:
            result = requests.post(url=url, data=data, headers=headers)
            return result.json()['choices'][0]['message']['content']
        except Exception as e:
            print(f"Ошибка при отправке запроса: {e}")
            return None

    def start(self):
        @self.client.on(events.NewMessage(pattern=r'\.ft'))
        async def handle_message(event):
            question = event.raw_text[4:].strip()  
            if question:
             
                messages = [{"role": "user", "content": question}]
                
                answer = self.deep_infra_chat(messages)
                
                if answer:

                    await event.delete()
             
                    await event.respond(answer)
                else:
                    await event.respond("Извините, не удалось получить ответ.")
            else:
                await event.respond('Пожалуйста, введите вопрос после .ft.')

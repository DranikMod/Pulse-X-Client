# plugins/ping_plugin.py

import time
from telethon import events

class Plugin:
    def __init__(self, client):
        self.client = client
        self.start()

    def start(self):
        @self.client.on(events.NewMessage(pattern=r'\.pinc'))
        async def ping(event):
            start_time = time.time()
            message = await event.reply("Проверка пинга... 🌐")
            
            elapsed_time = time.time() - start_time
            ping_time = round(elapsed_time * 1000, 2)
            
            response = (
                "🏓 **Пинг:** `{}` ms\n"
                "🌐 **Проверка завершена!**"
            ).format(ping_time)
            
            await message.delete()
            await event.reply(response, parse_mode='markdown')
            
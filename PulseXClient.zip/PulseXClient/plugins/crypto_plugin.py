# plugins/crypto_plugin.py

import requests
from telethon import events

class Plugin:
    def __init__(self, client):
        self.client = client
        self.start()

    def start(self):
        @self.client.on(events.NewMessage(pattern=r'\.crypto (.+)'))
        async def crypto(event):
            coin_id = event.pattern_match.group(1).lower()  
            typing_message = await event.reply("Запрашиваю данные о криптовалюте... ⏳")
            
            response = requests.get(f"https://api.coingecko.com/api/v3/simple/price?ids={coin_id}&vs_currencies=usd&include_24hr_change=true")
            
            if response.status_code == 200:
                data = response.json()
                if coin_id in data:
                    price = data[coin_id]['usd']
                    change = data[coin_id]['usd_24h_change']
                    
                    response_message = (
                        f"💰 **{coin_id.capitalize()}**\n"
                        f"💵 **Цена:** ${price:.2f}\n"
                        f"📈 **Изменение за 24 часа:** {change:.2f}%"
                    )
                else:
                    response_message = "❌ Не удалось найти криптовалюту. Проверьте название."
            else:
                response_message = "❌ Не удалось получить данные о криптовалюте. Попробуй позже."
            
            await typing_message.delete()
            await event.reply(response_message, parse_mode='markdown')
            